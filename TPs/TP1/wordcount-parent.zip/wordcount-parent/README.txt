Author : DJEBIEN Tarik
Remarques : 
j'ai utilisé le fichier test.txt pour mes tests JUnit, il faut changer
le path du fichier dans la classe de test dans le @Before.

Cordialement.