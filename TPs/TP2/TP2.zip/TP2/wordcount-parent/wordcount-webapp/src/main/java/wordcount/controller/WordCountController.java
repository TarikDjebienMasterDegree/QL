package wordcount.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import wordcount.service.IWordCount;
import wordcount.service.impl.WordCountBrut;

public class WordCountController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	public IWordCount wordCountTextBrut;
	public IWordCount wordCountTextUrl;
	
	@Override
	public void init() throws ServletException {
		super.init();
		String textPathFile = "/Users/tarik/Desktop/test.txt";
		wordCountTextBrut = new WordCountBrut(textPathFile);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		req.setAttribute("countAllWordInTextResponse", wordCountTextBrut.countAllWordInText().toString());
		req.setAttribute("countOneWordInTextResponse", wordCountTextBrut.countOneWordInText(req.getParameter("countOneWordInTextValue")));
		req.setAttribute("isWordInTextResponse", Boolean.toString(wordCountTextBrut.isWordInText(req.getParameter("isWordInTextValue"))));
		List<String> forbiddenWords = new ArrayList<String>();
		forbiddenWords.add(req.getParameter("forbiddenValue"));
		req.setAttribute("getAllFrequentWordsInTextResponse", wordCountTextBrut.getAllFrequentWordsInText(forbiddenWords, Integer.parseInt((String)req.getParameter("NValue"))).toString());
		req.getRequestDispatcher("WEB-INF/jsp/home.jsp").forward(req, resp);
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}

}
